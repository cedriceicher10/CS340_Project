function selectPlanet(id){
    $("#planet-selector").val(id);
}