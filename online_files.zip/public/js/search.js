// Determine which button was pressed
document.getElementById("searchButton1").addEventListener("click", function(){
	// Search 1
	alert("You pressed the first search button");
	button = 1;
	
});
document.getElementById("searchButton2").addEventListener("click", function(){
	// Search 2
	alert("You pressed the second search button");
	button = 2;
	
});

// Search portion
// Coming soon